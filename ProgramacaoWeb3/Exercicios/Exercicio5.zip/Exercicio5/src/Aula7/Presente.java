package Aula7;

public class Presente {
	
	String nome;
	String Presente1;
	String Presente2;
	String Presente3;
	
	public Presente (String nome, String presente1, String presente2, String presente3){
		this.nome = nome;
		this.Presente1 = presente1;
		this.Presente2 = presente2;
		this.Presente3 = presente3;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getPresente1() {
		return Presente1;
	}
	public void setPresente1(String presente1) {
		Presente1 = presente1;
	}
	public String getPresente2() {
		return Presente2;
	}
	public void setPresente2(String presente2) {
		Presente2 = presente2;
	}
	public String getPresente3() {
		return Presente3;
	}
	public void setPresente3(String presente3) {
		Presente3 = presente3;
	}

}
